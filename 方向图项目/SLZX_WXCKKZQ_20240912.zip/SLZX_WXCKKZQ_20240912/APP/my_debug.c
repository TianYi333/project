#include "my_debug.h"


void Debug_Print(const char* buf, ...)
{
  char str[256] = {0};
	
  va_list v;
  va_start(v, buf);
  vsprintf(str, buf, v); //使用可变参数的字符串打印。类似sprintf
	HAL_UART_Transmit(&huart1, (uint8_t *)str, strlen(str), 0xffff);
  va_end(v);
}
////数据操作函数

void MyDebug_TranData_Fun(uint8_t *databuf,uint16_t datalen)
{
	HAL_UART_Transmit(&huart1, (uint8_t *)databuf, datalen, 0xffff);
}






