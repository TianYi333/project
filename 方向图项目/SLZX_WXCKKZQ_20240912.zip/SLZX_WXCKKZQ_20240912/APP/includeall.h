#ifndef __INCLUDEALL_H
#define __INCLUDEALL_H

#include <stm32f1xx_hal.h>

#include <stdbool.h>
#include <string.h> 
#include <stdlib.h>
#include <stdio.h>
#include <string.h>  
#include <stdarg.h>
#include <stddef.h>

#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

#include "usart.h"

#include "my_debug.h"
#include "my_rs485.h"
#include "Air_4G.h"

#include "iwdg.h"

#include "stm32flash.h"

//����汾��
#define PROGRAM_VERSION   "SLZX-GFTS-V1.0.0"
#define RUN_APP_ADDR    0x8004000 //����APP��ǵ�ַ
#define UPGRADE_MARKER_BIT_ADDR  0x0800FC00    //���һҳ���˴��������־λ

extern osMutexId_t Rs485OutData_myMutex03Handle;
extern osMutexId_t DebugOutData_myMutex02Handle;
extern osMutexId_t Air4GOutData_myMutex01Handle;
#endif


