#ifndef __MY_DEBUG_H
#define __MY_DEBUG_H

#include "includeall.h"


#define DEBUG_DATA_SIGN  0
#define DEBUG_DATA_LEN   1
#define DEBUG_DATA_BUF   2
#define DEBUG_DATA_ALL   3


void Debug_Print(const char* buf, ...);

void MyDebug_DataSignRes(uint8_t null);
void MyDebug_TranData_Fun(uint8_t *databuf,uint16_t datalen);

#define DEBUG_ON

#ifdef DEBUG_ON

    #define DEBUG_PUT(fmt,arg...)            printf(""fmt"",##arg)
		#define DEBUG_ERROR(fmt,arg...)          printf("<<-FLASH-ERROR->> "fmt"\n",##arg)
		#define DEBUG_PUTF(f,fmt,arg...)         printf(""fmt" <F:%s L:%d>\r\n",##arg,f,__LINE__)	
		#define DEBUG_DEBUG(debug,POW,fmt,arg...)          do{\
																							if(debug)\
																								printf(" <%s> <%s> <%d> : "fmt"\n",__FILE__,__FUNCTION__,__LINE__, ##arg);\
																							}while(POW)
#else
		#define DEBUG_PUT(fmt,arg...)           
		#define DEBUG_ERROR(fmt,arg...)    
		#define DEBUG_PUTF(f,fmt,arg...)        																							
		#define DEBUG_DEBUG(debug,POW,fmt,arg...)         
#endif

#endif

