#include "Air_4G.h"

//4G串口数据操作

//数据操作函数
void Air4G_Print(const char* buf, ...)
{
  char str[128] = {0};
	
  va_list v;
  va_start(v, buf);
  vsprintf(str, buf, v); //使用可变参数的字符串打印。类似sprintf
	HAL_UART_Transmit(&huart3, (uint8_t *)str, strlen(str), 0xffff);
  va_end(v);
}

//操作函数
void Air4G_TranData_Fun(uint8_t *databuf,uint16_t datalen)
{
	osMutexAcquire (Air4GOutData_myMutex01Handle, 100);
	HAL_UART_Transmit(&huart3, (uint8_t *)databuf, datalen, 0xffff);
	osMutexRelease (Air4GOutData_myMutex01Handle);

}

bool Air4G_DataDispose_Fun(uint8_t *data,uint16_t datalen)
{
		osMutexAcquire (Air4GOutData_myMutex01Handle, 100);
//用字符的形式发送ID
		Air4G_Print("{\"id\":\"%s\",\"data\":\"",(char*)DTUID);
	//发送数据
    HAL_UART_Transmit(&huart3, (uint8_t *)data, datalen, 0xffff);
	//发送余下格式
	  Air4G_Print("\"}",(char*)DTUID);
	
	  osMutexRelease (Air4GOutData_myMutex01Handle);
return true;
}



