#ifndef __AIR_4G_H
#define __AIR_4G_H

#include "includeall.h"

typedef struct{//存放上位机查询的指令
 bool sign;//有无数据标记	
 uint8_t databuf[128];	
}Air4gDatatype;
extern Air4gDatatype Air4gData;


void Air4G_DataSignRes(uint8_t null);

bool Air4G_DataDispose_Fun(uint8_t *data,uint16_t datalen);
void Air4G_TranData_Fun(uint8_t *databuf,uint16_t datalen);


#endif
