/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include "includeall.h"
#include "my_debug.h"
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */
//�������ݽ��չ���serial port
#define SERIAL_PORT_DATA_SIGN  0 //��λ���
#define SERIAL_PORT_DATA_LEN   1
#define SERIAL_PORT_DATA_BUF   2
#define SERIAL_PORT_DATA_ALL   3  
#define SERIAL_PORT_DIRECTION_USART1         0  
#define SERIAL_PORT_DIRECTION_USART2_RS485   1  
#define SERIAL_PORT_DIRECTION_USART3_DTU     2  

#define SERIAL_PORT_DATA_BUFLEN   128
typedef struct{
 bool sign;//�������ݱ��
 uint8_t direction;//���ݽ��յķ���
 uint16_t datalen;
 uint8_t databuf[SERIAL_PORT_DATA_BUFLEN];	
}SerialPortDatatype;
extern SerialPortDatatype SerialPortData;

//���ڲ����ʿ���
#define BOUD_RATE_PIN_1  HAL_GPIO_ReadPin(BOOT_1_GPIO_Port, BOOT_1_Pin)
#define BOUD_RATE_PIN_2  HAL_GPIO_ReadPin(BOOT_2_GPIO_Port, BOOT_2_Pin)
#define BOUD_RATE_2400    0
#define BOUD_RATE_9600    1
#define BOUD_RATE_115200  2
#define BOUD_RATE_600000  3

extern uint8_t boud_rate_sign;//��¼�������޸�

 void Main_SerialPortData_DataSignRes(uint8_t null);
 void Main_BoutRateSet_Fun(uint32_t bout);
uint8_t Main_BoutRate_Fun(void);

//���ߺ�����ģʽ����
#define DTU_ONOFF       1 //HAL_GPIO_ReadPin(BOOT_2_GPIO_Port, BOOT_2_Pin)
#define DTU_ON 1
#define DTU_OFF 0


/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */
#define DTUID_LEN 16
typedef struct{
uint8_t dtuid[DTUID_LEN];
bool 	dtuidsign ;
}DtuIdType; 
extern DtuIdType DtuId;
#define DTUID   DtuId.dtuid
/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define RS485_RE_Pin GPIO_PIN_1
#define RS485_RE_GPIO_Port GPIOA
#define RS485_TX_Pin GPIO_PIN_2
#define RS485_TX_GPIO_Port GPIOA
#define RS485_RX_Pin GPIO_PIN_3
#define RS485_RX_GPIO_Port GPIOA
#define MOD_GPS_Pin GPIO_PIN_7
#define MOD_GPS_GPIO_Port GPIOA
#define MOD_RDY_Pin GPIO_PIN_0
#define MOD_RDY_GPIO_Port GPIOB
#define MOD_RST_Pin GPIO_PIN_1
#define MOD_RST_GPIO_Port GPIOB
#define BOOT_2_Pin GPIO_PIN_15
#define BOOT_2_GPIO_Port GPIOB
#define BOOT_1_Pin GPIO_PIN_8
#define BOOT_1_GPIO_Port GPIOA
#define USB_RX_Pin GPIO_PIN_9
#define USB_RX_GPIO_Port GPIOA
#define USB_TX_Pin GPIO_PIN_10
#define USB_TX_GPIO_Port GPIOA
#define MCU_LED_Pin GPIO_PIN_11
#define MCU_LED_GPIO_Port GPIOA
#define NET_LED_Pin GPIO_PIN_12
#define NET_LED_GPIO_Port GPIOA

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
