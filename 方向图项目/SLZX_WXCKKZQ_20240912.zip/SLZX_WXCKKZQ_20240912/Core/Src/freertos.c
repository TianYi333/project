/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "includeall.h"
#include "my_debug.h"
#include "my_rs485.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

/* USER CODE END Variables */
/* Definitions for defaultTask */
osThreadId_t defaultTaskHandle;
const osThreadAttr_t defaultTask_attributes = {
  .name = "defaultTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for myTask02 */
osThreadId_t myTask02Handle;
const osThreadAttr_t myTask02_attributes = {
  .name = "myTask02",
  .stack_size = 256 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for Air4GOutData_myMutex01 */
osMutexId_t Air4GOutData_myMutex01Handle;
const osMutexAttr_t Air4GOutData_myMutex01_attributes = {
  .name = "Air4GOutData_myMutex01"
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void *argument);
void myStartTask02(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* Hook prototypes */
void vApplicationStackOverflowHook(xTaskHandle xTask, signed char *pcTaskName);

/* USER CODE BEGIN 4 */
void vApplicationStackOverflowHook(xTaskHandle xTask, signed char *pcTaskName)
{
   /* Run time stack overflow checking is performed if
   configCHECK_FOR_STACK_OVERFLOW is defined to 1 or 2. This hook function is
   called if a stack overflow is detected. */
	DEBUG_PUT("\r\n�ڴ��������=%s\r\n",pcTaskName);

}
/* USER CODE END 4 */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */
  /* Create the mutex(es) */
  /* creation of Air4GOutData_myMutex01 */
  Air4GOutData_myMutex01Handle = osMutexNew(&Air4GOutData_myMutex01_attributes);

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of defaultTask */
  defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);

  /* creation of myTask02 */
  myTask02Handle = osThreadNew(myStartTask02, NULL, &myTask02_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  /* USER CODE BEGIN StartDefaultTask */
//	uint8_t*p = NULL;
  /* Infinite loop */
  for(;;)
  {
//		if(DtuId.dtuidsign == false)
//		{//���ID����Ϊ�գ���ȡID,��4Gģ���IMEI��			
//		 Air4G_TranData_Fun((uint8_t*)"config,get,imei\r\n",sizeof("config,get,imei\r\n")-1);
//		 osDelay(500);
//     if(SerialPortData.sign == true)
//		 {
//				if(NULL != strstr((char*)SerialPortData.databuf,"config,imei,ok"))
//				{
//				 uint8_t *p = NULL,datalen=0,j=0;
//				 p = (uint8_t*)strstr((char*)SerialPortData.databuf,"ok");
//				 p+=3;
//				 datalen = strlen((char*)p);
//				 for(uint8_t i=0;i<datalen-2;i++)
//				 {
//					DTUID[j++] = p[i];
//				 }	
//				 DTUID[j]=0;
//				 DtuId.dtuidsign = true;
//				 Main_SerialPortData_DataSignRes(SERIAL_PORT_DATA_ALL);
//		     DEBUG_PUT("\r\nDTUID=%s\r\n",DTUID);
//				}else{
//				 Main_SerialPortData_DataSignRes(SERIAL_PORT_DATA_ALL);
//				}
//		 }			 
//		}

		osDelay(500);
			if(true == HAL_GPIO_ReadPin(MOD_RDY_GPIO_Port, MOD_RDY_Pin))
			{	//����		  
        HAL_GPIO_WritePin(NET_LED_GPIO_Port,NET_LED_Pin,GPIO_PIN_SET);			
			}else{	//������		  
        HAL_GPIO_WritePin(NET_LED_GPIO_Port,NET_LED_Pin,GPIO_PIN_RESET);				  
			}	
		HAL_GPIO_TogglePin(MCU_LED_GPIO_Port,MCU_LED_Pin);
		HAL_IWDG_Refresh(&hiwdg);
  }
  /* USER CODE END StartDefaultTask */
}

/* USER CODE BEGIN Header_myStartTask02 */
/**
* @brief Function implementing the myTask02 thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_myStartTask02 */
void myStartTask02(void *argument)
{
  /* USER CODE BEGIN myStartTask02 */
  /* Infinite loop */
  for(;;)
  {	
		if(DtuId.dtuidsign == true)
		{//�Զ�ȡID	
			if(SerialPortData.sign == true)
			{
				//��̬���ò�����
				if(BOUD_RATE_2400 == Main_BoutRate_Fun())
				{
					if(boud_rate_sign != BOUD_RATE_2400)
					{
						Main_BoutRateSet_Fun(2400);boud_rate_sign=BOUD_RATE_2400;				
					}
				}else if(BOUD_RATE_9600 == Main_BoutRate_Fun()){
					if(boud_rate_sign != BOUD_RATE_9600)
					{
						Main_BoutRateSet_Fun(9600);boud_rate_sign=BOUD_RATE_9600;				
					}
				}else if(BOUD_RATE_115200 == Main_BoutRate_Fun()){
					if(boud_rate_sign != BOUD_RATE_115200)
					{
						Main_BoutRateSet_Fun(115200);boud_rate_sign=BOUD_RATE_115200;				
					}
				}else {
					if(boud_rate_sign != BOUD_RATE_600000)
					{
						Main_BoutRateSet_Fun(2400);boud_rate_sign=BOUD_RATE_600000;				
					}
				}
				//��������
				if(SerialPortData.direction == SERIAL_PORT_DIRECTION_USART2_RS485)
				{
					if(DTU_ONOFF == DTU_ON)
					{//��dtu
						Air4G_DataDispose_Fun((uint8_t *)SerialPortData.databuf, SerialPortData.datalen);					
					}
					HAL_UART_Transmit(&huart1,(uint8_t *)SerialPortData.databuf, SerialPortData.datalen, 0xffff);
				}else{
					HAL_UART_Transmit(&huart2,(uint8_t *)SerialPortData.databuf, SerialPortData.datalen, 0xffff);		
				}
				Main_SerialPortData_DataSignRes(SERIAL_PORT_DATA_ALL);  
			}	
	  }
    osDelay(100);
  }
  /* USER CODE END myStartTask02 */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

