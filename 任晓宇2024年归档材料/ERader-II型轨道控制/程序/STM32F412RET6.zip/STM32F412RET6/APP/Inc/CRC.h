#ifndef _CRC_H_
#define _CRC_H_
#include "stm32f4xx_hal.h"

extern uint16_t CRC16(uint8_t * pMsg, uint16_t Len);


#endif

