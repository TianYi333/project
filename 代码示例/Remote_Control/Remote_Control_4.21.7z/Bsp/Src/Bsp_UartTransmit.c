#include "Bsp_UartTransmit.h"

void Uart_Transmit_Function(void)
{
  while(1)
  {
    vTaskDelay(300);
    
  }
}
