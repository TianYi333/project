#ifndef __BSP_BATTERY_H__
#define __BSP_BATTERY_H__

#include "main.h"

void Batery_Function(void);

#endif
