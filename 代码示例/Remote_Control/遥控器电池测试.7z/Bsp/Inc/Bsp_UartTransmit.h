#ifndef __BSP_UARTTRANSMIT_H__
#define __BSP_UARTTRANSMIT_H__

#include "main.h"

void Uart_Transmit_Function(void);

#endif
