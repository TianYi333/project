#ifndef _CRC_H_
#define _CRC_H_
#include "main.h"


extern uint16_t CRC16(uint8_t * pMsg, uint16_t Len);

#endif

